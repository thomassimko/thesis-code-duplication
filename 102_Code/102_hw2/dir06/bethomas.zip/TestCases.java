
public class TestCases 
{
	public static void main(String args[])
	{
		Expression test1 = new DoubleConstantExpression(3);
		Check.check(test1.evaluate(null), 3);
		Expression test2 = new NegationExpression(test1);
		Check.check(test2.evaluate(null), -3);
		Expression test3 = new AddExpression(test1, test2);
		Check.check(test3.evaluate(null), 0);
		Expression test4 = new SubtractExpression(test2, test3);
		Check.check(test4.evaluate(null), -3);
		Expression test5 = new DivideExpression(test4, test2);
		Check.check(test5.evaluate(null), 1);
		Expression test6 = new MultiplyExpression(new DoubleConstantExpression(90), new DoubleConstantExpression(4.2));
		Check.check(test6.evaluate(null), 378);
		Expression test7 = new DivideExpression(test6, test2);
		Check.check(test7.evaluate(null), -126);
		Check.check(new AddExpression(new DoubleConstantExpression(7), test2).evaluate(null), 4);
		Check.check(new DivideExpression(test6, test7).evaluate(null), -3);
		Check.check(new NegationExpression(test7).evaluate(null), 126);
		Check.check(new MultiplyExpression(test6, test7).evaluate(null), -47628);
		Check.check(new Binding("hello", 56).getId(), "hello");
		Check.check(new Binding("tester", -45).getValue(), -45);
		Check.check(new Binding("pi", 3.14159).getValue(), 3.14159);
	}
}
