
public class IdentifierExpression implements Expression
{
	private String idSearch;
	
	public IdentifierExpression(String idSearch)
	{
		this.idSearch = idSearch;
	}
	public double evaluate(Bindings bindings) 
	{
		return bindings.lookupBinding(idSearch);
	}
	
	public String toString()
	{
		return idSearch;
	}

}
