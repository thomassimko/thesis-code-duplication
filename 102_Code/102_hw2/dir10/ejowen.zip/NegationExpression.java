
public class NegationExpression implements Expression {
	private Expression e;

	public NegationExpression (Expression e) {
		this.e = e;
	}
	@Override
	public double evaluate(Bindings bindings) {
		double negatedEval;
		negatedEval = -1 * e.evaluate(bindings);
		return negatedEval;
	}
	public String toString() {
		return "-" + e.evaluate(null) + "";
	}
}
