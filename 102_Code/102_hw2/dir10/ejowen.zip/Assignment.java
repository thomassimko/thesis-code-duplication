
public class Assignment implements Operation {
	String id;
	Expression e;
	
	public Assignment (String id, Expression e) {
		this.id = id;
		this.e = e;	
	}
	@Override
	public double evaluate(Bindings bindings) {
		//Binding b = new Binding(id, e.evaluate(bindings));
		bindings.addBinding(id, e.evaluate(bindings));
		return e.evaluate(bindings);
	}
	public String toString() {
		return "set " + id + " = " + e.toString();
	}

}
