
public class TestCases {
	
	public static void testDoubleConstantExpression () {
		DoubleConstantExpression d = new DoubleConstantExpression(3.0);
		Check.check(d.evaluate(null), 3);
		Check.check(d.toString(), "3.0");
		}
	public static void testNegatedConstantExpression () {
		Expression ce = new DoubleConstantExpression(5.2);
		Expression nce = new NegationExpression(ce);
		Check.check(nce.evaluate(null), -5.2);
		Check.check(nce.toString(), "-5.2");
	}
	public static void testAddExpression() {
		Expression lft = new DoubleConstantExpression(5.0);
		Expression rht = new DoubleConstantExpression(1.5);
		Expression addexp = new AddExpression(lft, rht);
		Check.check(addexp.evaluate(null), 6.5);
		Check.check(addexp.toString(), "(5.0 + 1.5)");
	}
	public static void testSubtractExpression() {
		Expression lft = new DoubleConstantExpression(0.0);
		Expression rht = new DoubleConstantExpression(7.7);
		Expression subexp = new SubtractExpression(lft, rht);
		Check.check(subexp.evaluate(null), -7.7);
		Check.check(subexp.toString(), "(0.0 - 7.7)");
	}
	public static void testMultiplyExpression() {
		Expression lft = new DoubleConstantExpression(10);
		Expression rht = new DoubleConstantExpression(-2);
		Expression multexp = new MultiplyExpression(lft, rht);
		Check.check(multexp.evaluate(null), -20);
		Check.check(multexp.toString(), "(10.0 * -2.0)");
		}
	public static void testDivideExpression() {
		Expression lft = new DoubleConstantExpression(10.0);
		Expression rht = new DoubleConstantExpression(2.5);
		Expression divexp = new DivideExpression(lft, rht);
		Check.check(divexp.evaluate(null), 4.0);
		Check.check(divexp.toString(), "(10.0 / 2.5)");
	}
	public static void testBinding() {
		Binding b = new Binding("hello", 4);
		Check.check(b.getId(), "hello");
		Check.check(b.getValue(), 4);
	}
	public static void testVariableBindings(){
		Bindings b = new VariableBindings();
		b.addBinding("hi", 4);
		Check.check(b.lookupBinding("hi"), 4);
	}
	/*public static void testAssignment() {
		Expression exp = new DoubleConstantExpression(6.0);
		String hello = "hello";
		Assignment a = new Assignment(hello, exp);
		Check.check(a.evaluate(null), 6.0);
		Check.check(a.toString(), "set hello = 1.0");
	}*/
	public static void main (String [] args){
		testDoubleConstantExpression();
		testNegatedConstantExpression();
		testAddExpression();
		testSubtractExpression();
		testMultiplyExpression();
		testDivideExpression();
		testBinding();
		testVariableBindings();
		/*testAssignment();*/
	}
}
