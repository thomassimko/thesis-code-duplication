
public class AddExpression implements Expression {
	private Expression rht, lft;
	
	public AddExpression (Expression lft, Expression rht) {
		this.lft = lft;
		this.rht = rht;
	}
	@Override
	public double evaluate(Bindings bindings) {
		double sum;
		sum = lft.evaluate(bindings) + rht.evaluate(bindings);
		return sum;
	}
	public String toString() {
		return "(" +lft.toString() + " + " + rht.toString() + ")";
	}
}
