
public class IdentifierExpression implements Expression{
	private String search;
	
	public IdentifierExpression (String search) {
		this.search = search;
	}

	@Override
	public double evaluate(Bindings bindings) {
		double answer;
		answer = bindings.lookupBinding(search);
		return answer;
	}
	public String toString() {
		return "" + search + "";
	}
}
