
public class DivideExpression implements Expression {
	private Expression lft, rht;
	
	public DivideExpression (Expression lft, Expression rht) {
		this.lft = lft;
		this.rht = rht;
	}
	@Override
	public double evaluate(Bindings bindings) {
		double total;
		total = lft.evaluate(bindings) / rht.evaluate(bindings);;
		return total;
	}
	public String toString() {
		return "(" + lft.toString() + " / " + rht.toString() + ")";
	}
}
