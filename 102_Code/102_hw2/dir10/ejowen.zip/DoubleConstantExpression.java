
public class DoubleConstantExpression implements Expression {
	private double expression;
	
	public DoubleConstantExpression (double expression) {
		this.expression = expression;
	}
	@Override
	public double evaluate(Bindings bindings) {
		return expression;
	}
	public String toString() {
		return "" + expression + "";
	}

}
