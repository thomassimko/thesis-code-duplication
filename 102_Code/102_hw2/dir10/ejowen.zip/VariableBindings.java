import java.util.ArrayList;
import java.util.List;

public class VariableBindings implements Bindings {
	private List<Binding> bindlist;
	
	
	public VariableBindings(){
		bindlist = new ArrayList<Binding>();
	}
	@Override
	public void addBinding(String id, double value) {
		Binding b = new Binding(id, value);
		bindlist.add(b);
		//System.out.println("Why won't this add?");
	}

	@Override
	public double lookupBinding(String id) throws UnboundIdentifierException {
		for (int i = 0; i<bindlist.size(); i++) {
			if (bindlist.get(i).getId().equals(id)) {
				return bindlist.get(i).getValue();
			}
		}
		throw new UnboundIdentifierException("unbound identifier: " + id);
	}

}
